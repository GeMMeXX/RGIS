using System;

public class RegistracijaKontroler {
	public bool PreveriPodatke() {
		throw new System.NotImplementedException("Not implemented");
	}
	public RegistracijaKontroler() {
		throw new System.NotImplementedException("Not implemented");
	}

	private Tekmovalec tekmovalec;
    public Tekmovalec UstvariTekmovalca()
    {
        Tekmovalec t = new Tekmovalec()
        {
            ime = "Marko",
            priimek = "Novak",
            letoRojstva = 2000
        };
        return t;
    }
}
