using System;

public class PritozbaKontroler {
	public void SprejmiPritozbo() {
		throw new System.NotImplementedException("Not implemented");
	}
	public void ObdelajPritozbo() {
		throw new System.NotImplementedException("Not implemented");
	}

	private Pritozba pritozba;
	private Organizator organizator;
	private Sodnik sodnik;

}
