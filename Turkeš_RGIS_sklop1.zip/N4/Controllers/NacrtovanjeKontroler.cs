using System;

public class NacrtovanjeKontroler {
	public List<Tekma> GenerirajPare() {
		throw new System.NotImplementedException("Not implemented");
	}
	public void ShraniTekme() {
		throw new System.NotImplementedException("Not implemented");
	}

	private Kategorija kategorija;
	private Tekma tekma;

}
