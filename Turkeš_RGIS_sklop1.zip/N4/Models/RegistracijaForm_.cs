using System;

public class RegistracijaForm_ {
	public void VnesiPodatke() {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PotrdiRegistracijo() {
		throw new System.NotImplementedException("Not implemented");
	}

}
