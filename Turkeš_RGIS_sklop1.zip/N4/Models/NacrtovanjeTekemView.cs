using System;

public class NacrtovanjeTekemView {
	public void IzberiKategorijo() {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PotrdiGeneriranje() {
		throw new System.NotImplementedException("Not implemented");
	}

}
