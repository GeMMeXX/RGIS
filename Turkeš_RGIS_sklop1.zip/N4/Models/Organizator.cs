using System;

public class Organizator {
    public string ime;

	public string PreglejPritozbo() {
		throw new System.NotImplementedException("Not implemented");
	}

	private PritozbaKontroler pritozbaKontroler;

}
