using System;

public class PritozbaView {
	public void VnesiPritozbo() {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PrikaziOdlocitev() {
		throw new System.NotImplementedException("Not implemented");
	}

}
