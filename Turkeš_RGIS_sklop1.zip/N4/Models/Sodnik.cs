using System;

public class Sodnik {
    public string ime;

	public void PosredujPritozbo() {
		throw new System.NotImplementedException("Not implemented");
	}

	private PritozbaKontroler pritozbaKontroler;

}
