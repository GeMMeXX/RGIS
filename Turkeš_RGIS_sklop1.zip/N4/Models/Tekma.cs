using System;

public class Tekma {
    public int id;
    public Tekmovalec tekmovalec1;
    public Tekmovalec tekmovalec2;
    public string kategorija;
    public string rezultat;

	private NacrtovanjeKontroler nacrtovanjeKontroler;
	private Pritozba pritozba;

}
