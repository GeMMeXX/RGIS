using System;

public class Tekmovalec {
    public string ime;
    public string priimek;
    public int letoRojstva;
    public string kategorija;

	private RegistracijaKontroler registracijaKontroler;
	private Pritozba pritozba;

}
