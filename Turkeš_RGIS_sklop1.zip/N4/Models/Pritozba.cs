using System;

public class Pritozba {
    public int id;
    public Tekmovalec tekmovalec;
    public Tekma tekma;
    public string status;
    public string odlocitev;

	private PritozbaKontroler pritozbaKontroler;

}
