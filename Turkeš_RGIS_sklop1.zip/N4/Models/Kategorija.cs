using System;

public class Kategorija {
    public string ime;
    public List<Tekmovalec> tekmovalci;

	private NacrtovanjeKontroler nacrtovanjeKontroler;
	private Tekmovalec tekmovalec;

}
